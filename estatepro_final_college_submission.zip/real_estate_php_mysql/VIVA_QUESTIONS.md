# Viva / Presentation Questions

### What is the purpose of the project?
To computerize property, client, owner, agent and transaction management for a real-estate business.

### Why MySQL?
It is a relational database suitable for structured entities and foreign-key relationships.

### Why PHP?
PHP is widely supported by XAMPP and is suitable for server-rendered CRUD applications.

### What is PDO?
PHP Data Objects, used here for secure database access and prepared statements.

### How are passwords secured?
Using PHP's `password_hash()` and `password_verify()` functions.

### What is a foreign key?
A field that references a primary key in another table and maintains relational integrity.

### What is CSRF protection?
A token mechanism that prevents unauthorized cross-site form submissions.

### How does image upload work?
The server validates MIME type and file size, generates a random filename and stores the file path in `property_images`.

### How are PDFs generated?
Reports are print-optimized HTML pages. The browser can use Print → Save as PDF, avoiding dependency on an external PDF package.

### What are the main users?
ADMIN, AGENT and STAFF roles.

### What makes the project different from a simple CRUD?
It combines authentication, role control, analytics, filtering, media management, transaction documents and printable reports.
