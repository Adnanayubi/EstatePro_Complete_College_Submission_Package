<?php
require_once '../config/config.php'; require_login(); verify_csrf();
$pdo=db(); $id=query_int('id'); $row=null;
if($id){$s=$pdo->prepare("SELECT * FROM properties WHERE property_id=?");$s->execute([$id]);$row=$s->fetch();if(!$row)redirect('property/index.php');}
$owners=$pdo->query("SELECT owner_id,owner_name FROM owners ORDER BY owner_name")->fetchAll();
$addresses=$pdo->query("SELECT address_id,address_street,city_name FROM addresses ORDER BY city_name,address_street")->fetchAll();
$clients=$pdo->query("SELECT client_id,client_name FROM clients ORDER BY client_name")->fetchAll();
if($_SERVER['REQUEST_METHOD']==='POST'){
  $id=post_int('property_id');
  $v=[$_POST['property_date_add']?:null,trim($_POST['property_address']??''),post_int('client_id'),post_int('rooms'),post_int('bedrooms'),post_int('bathrooms'),post_int('garage'),trim($_POST['description']??''),post_int('address_id'),post_int('owner_id'),$_POST['listing_type']??'RENT',$_POST['status']??'AVAILABLE'];
  if($id){$s=$pdo->prepare("UPDATE properties SET property_date_add=?,property_address=?,client_id=?,property_num_of_rooms=?,property_num_of_bedroom=?,property_num_of_bathroom=?,property_num_of_garage=?,property_description=?,address_id=?,owner_id=?,listing_type=?,status=? WHERE property_id=?");$s->execute([...$v,$id]);}
  else{$s=$pdo->prepare("INSERT INTO properties(property_date_add,property_address,client_id,property_num_of_rooms,property_num_of_bedroom,property_num_of_bathroom,property_num_of_garage,property_description,address_id,owner_id,listing_type,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");$s->execute($v);$id=(int)$pdo->lastInsertId();}
  $pdo->prepare("DELETE FROM property_for_rent WHERE property_id=?")->execute([$id]);
  $pdo->prepare("DELETE FROM property_for_sale WHERE property_id=?")->execute([$id]);
  if(in_array($_POST['listing_type']??'', ['RENT','BOTH'], true)) $pdo->prepare("INSERT INTO property_for_rent(property_id,rent_price,available_date) VALUES(?,?,?)")->execute([$id,post_decimal('rent_price')??0,$_POST['rent_available_date']?:null]);
  if(in_array($_POST['listing_type']??'', ['SALE','BOTH'], true)) $pdo->prepare("INSERT INTO property_for_sale(property_id,used_price,available_date) VALUES(?,?,?)")->execute([$id,post_decimal('sale_price')??0,$_POST['sale_available_date']?:null]);
  flash('success','Property saved.');redirect('property/index.php');
}
$title=$id?'Edit Property':'Add Property';require '../includes/header.php';
?>
<h2><?=e($title)?></h2><div class="card p-4"><form method="post"><?=csrf_field()?><input type="hidden" name="property_id" value="<?=e((string)$id)?>">
<div class="row g-3">
<div class="col-md-4"><label class="form-label">Date Added</label><input type="date" class="form-control" name="property_date_add" value="<?=e($row['property_date_add']??date('Y-m-d'))?>"></div>
<div class="col-md-8"><label class="form-label">Property Address</label><input required class="form-control" name="property_address" value="<?=e($row['property_address']??'')?>"></div>
<div class="col-md-4"><label class="form-label">Owner</label><select class="form-select" name="owner_id"><option value="">None</option><?php foreach($owners as $o):?><option value="<?=$o['owner_id']?>" <?=($row['owner_id']??null)==$o['owner_id']?'selected':''?>><?=e($o['owner_name'])?></option><?php endforeach;?></select></div>
<div class="col-md-4"><label class="form-label">Client</label><select class="form-select" name="client_id"><option value="">None</option><?php foreach($clients as $c):?><option value="<?=$c['client_id']?>" <?=($row['client_id']??null)==$c['client_id']?'selected':''?>><?=e($c['client_name'])?></option><?php endforeach;?></select></div>
<div class="col-md-4"><label class="form-label">Address Record</label><select class="form-select" name="address_id"><option value="">None</option><?php foreach($addresses as $a):?><option value="<?=$a['address_id']?>" <?=($row['address_id']??null)==$a['address_id']?'selected':''?>><?=e(($a['city_name']??'').' - '.($a['address_street']??''))?></option><?php endforeach;?></select></div>
<div class="col-md-3"><label class="form-label">Rooms</label><input type="number" class="form-control" name="rooms" value="<?=e($row['property_num_of_rooms']??'')?>"></div>
<div class="col-md-3"><label class="form-label">Bedrooms</label><input type="number" class="form-control" name="bedrooms" value="<?=e($row['property_num_of_bedroom']??'')?>"></div>
<div class="col-md-3"><label class="form-label">Bathrooms</label><input type="number" class="form-control" name="bathrooms" value="<?=e($row['property_num_of_bathroom']??'')?>"></div>
<div class="col-md-3"><label class="form-label">Garage</label><input type="number" class="form-control" name="garage" value="<?=e($row['property_num_of_garage']??'')?>"></div>
<div class="col-md-4"><label class="form-label">Listing Type</label><select class="form-select" name="listing_type"><?php foreach(['RENT','SALE','BOTH'] as $x):?><option <?=($row['listing_type']??'RENT')===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select></div>
<div class="col-md-4"><label class="form-label">Status</label><select class="form-select" name="status"><?php foreach(['AVAILABLE','RENTED','SOLD','INACTIVE'] as $x):?><option <?=($row['status']??'AVAILABLE')===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select></div>
<div class="col-md-4"><label class="form-label">Rent Price</label><input type="number" step="0.01" class="form-control" name="rent_price"></div>
<div class="col-md-4"><label class="form-label">Rent Available Date</label><input type="date" class="form-control" name="rent_available_date"></div>
<div class="col-md-4"><label class="form-label">Sale Price</label><input type="number" step="0.01" class="form-control" name="sale_price"></div>
<div class="col-md-4"><label class="form-label">Sale Available Date</label><input type="date" class="form-control" name="sale_available_date"></div>
<div class="col-12"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="4"><?=e($row['property_description']??'')?></textarea></div>
</div><button class="btn btn-primary mt-4">Save Property</button> <a class="btn btn-secondary mt-4" href="index.php">Cancel</a></form></div>
<?php require '../includes/footer.php'; ?>
