<?php
require_once '../config/config.php'; require_login(); verify_csrf(); $pdo=db(); $id=query_int('id'); if(!$id)redirect('property/index.php');
$s=$pdo->prepare("SELECT property_id,property_address FROM properties WHERE property_id=?");$s->execute([$id]);$property=$s->fetch();if(!$property)redirect('property/index.php');
$uploadError=null;
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_FILES['property_image'])){
    $file=$_FILES['property_image'];
    $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if($file['error']!==UPLOAD_ERR_OK) $uploadError='Upload failed.';
    elseif($file['size']>5*1024*1024) $uploadError='Maximum image size is 5 MB.';
    elseif(!isset($allowed[$mime])) $uploadError='Only JPG, PNG and WEBP images are allowed.';
    else{
        $name=bin2hex(random_bytes(12)).'.'.$allowed[$mime];
        if(move_uploaded_file($file['tmp_name'],__DIR__.'/../uploads/properties/'.$name)){
            $pdo->prepare("INSERT INTO property_images(property_id,file_name,original_name) VALUES(?,?,?)")->execute([$id,$name,$file['name']]);
            flash('success','Property photo uploaded.');redirect('property/images.php?id='.$id);
        } else $uploadError='Could not save the uploaded image.';
    }
}
if(isset($_GET['delete_image'])){$img=(int)$_GET['delete_image'];$s=$pdo->prepare("SELECT file_name FROM property_images WHERE image_id=? AND property_id=?");$s->execute([$img,$id]);$im=$s->fetch();if($im){@unlink(__DIR__.'/../uploads/properties/'.$im['file_name']);$pdo->prepare("DELETE FROM property_images WHERE image_id=?")->execute([$img]);flash('success','Photo deleted.');}redirect('property/images.php?id='.$id);}
$images=$pdo->prepare("SELECT * FROM property_images WHERE property_id=? ORDER BY image_id DESC");$images->execute([$id]);$images=$images->fetchAll();
$title='Property Photos';require '../includes/header.php';?>
<div class="d-flex justify-content-between align-items-center mb-3"><div><h2>Property Photos</h2><div class="text-muted"><?=e($property['property_address'])?></div></div><a class="btn btn-outline-secondary" href="index.php">Back</a></div>
<?php if($uploadError):?><div class="alert alert-danger"><?=e($uploadError)?></div><?php endif;?>
<div class="card p-4 mb-4 no-print"><form method="post" enctype="multipart/form-data"><?=csrf_field()?><div class="row align-items-end g-3"><div class="col-md-9"><label class="form-label">Upload photo</label><input required type="file" class="form-control" name="property_image" accept="image/jpeg,image/png,image/webp"><div class="form-text">JPG, PNG or WEBP; max 5 MB.</div></div><div class="col-md-3"><button class="btn btn-primary w-100"><i class="bi bi-cloud-upload"></i> Upload</button></div></div></form></div>
<div class="row g-4"><?php foreach($images as $im):?><div class="col-md-6 col-lg-4"><div class="card p-2"><img class="gallery-img" src="<?=BASE_URL?>/uploads/properties/<?=e($im['file_name'])?>" alt="<?=e($im['original_name'])?>"><div class="p-2 d-flex justify-content-between align-items-center"><small class="text-muted"><?=e($im['original_name'])?></small><a data-confirm="Delete this photo?" class="btn btn-sm btn-outline-danger no-print" href="images.php?id=<?=$id?>&delete_image=<?=$im['image_id']?>">Delete</a></div></div></div><?php endforeach;?></div>
<?php if(!$images):?><div class="card p-5 text-center text-muted">No photos uploaded yet.</div><?php endif;?>
<?php require '../includes/footer.php'; ?>
