<?php
require_once '../config/config.php'; require_login(); $pdo=db();
$id=query_int('id'); if(!$id) redirect('index.php');
$st=$pdo->prepare("SELECT p.*,o.owner_name,o.phone_num owner_phone,a.address_street,a.zip_code,a.country_name,a.city_name,pr.rent_price,pr.available_date rent_available,ps.used_price,ps.available_date sale_available
FROM properties p
LEFT JOIN owners o ON o.owner_id=p.owner_id
LEFT JOIN addresses a ON a.address_id=p.address_id
LEFT JOIN property_for_rent pr ON pr.property_id=p.property_id
LEFT JOIN property_for_sale ps ON ps.property_id=p.property_id
WHERE p.property_id=?");$st->execute([$id]);$p=$st->fetch();if(!$p)redirect('index.php');
$imgs=$pdo->prepare("SELECT * FROM property_images WHERE property_id=? ORDER BY image_id DESC");$imgs->execute([$id]);$imgs=$imgs->fetchAll();
$features=$pdo->prepare("SELECT f.feature_description FROM property_features pf JOIN features f ON f.feature_code=pf.feature_code WHERE pf.property_id=? ORDER BY f.feature_description");$features->execute([$id]);$features=$features->fetchAll(PDO::FETCH_COLUMN);
$title='Property Details';require '../includes/header.php';?>
<div class="d-flex justify-content-between align-items-center mb-4 no-print">
  <div><h2 class="mb-1">Property #<?=$p['property_id']?></h2><div class="text-muted"><?=e($p['property_address'])?></div></div>
  <div class="d-flex gap-2"><button class="btn btn-outline-secondary" data-print><i class="bi bi-printer"></i> Print</button><a class="btn btn-outline-primary" href="form.php?id=<?=$id?>">Edit</a><a class="btn btn-primary" href="index.php">Back</a></div>
</div>
<div class="print-only"><h1>Property Details Report</h1><p>Property #<?=$p['property_id']?> • Generated <?=date('d M Y, h:i A')?></p></div>
<div class="row g-4">
<div class="col-lg-7"><div class="card p-3"><div class="row g-3"><?php foreach($imgs as $im):?><div class="col-md-6"><img class="gallery-img" src="<?=BASE_URL?>/uploads/properties/<?=e($im['file_name'])?>" alt="Property image"></div><?php endforeach;?><?php if(!$imgs):?><div class="col-12"><div class="p-5 text-center bg-light rounded-3 text-muted"><i class="bi bi-house display-5"></i><div>No photos uploaded.</div></div></div><?php endif;?></div></div></div>
<div class="col-lg-5"><div class="card p-4"><h4><?=e($p['property_address'])?></h4><div class="d-flex gap-2 mb-3"><span class="badge badge-soft"><?=e($p['listing_type'])?></span><span class="badge text-bg-light"><?=e($p['status'])?></span></div>
<dl class="row small"><dt class="col-6">Rooms</dt><dd class="col-6"><?=$p['property_num_of_rooms']?></dd><dt class="col-6">Bedrooms</dt><dd class="col-6"><?=$p['property_num_of_bedroom']?></dd><dt class="col-6">Bathrooms</dt><dd class="col-6"><?=$p['property_num_of_bathroom']?></dd><dt class="col-6">Garage</dt><dd class="col-6"><?=$p['property_num_of_garage']?></dd><dt class="col-6">Owner</dt><dd class="col-6"><?=e($p['owner_name'])?></dd><dt class="col-6">City</dt><dd class="col-6"><?=e($p['city_name'])?></dd></dl>
<?php if($p['rent_price']!==null):?><div class="alert alert-primary">Rent: <strong>₹<?=money($p['rent_price'])?></strong> / month</div><?php endif;?>
<?php if($p['used_price']!==null):?><div class="alert alert-success">Sale price: <strong>₹<?=money($p['used_price'])?></strong></div><?php endif;?>
<h6>Description</h6><p><?=nl2br(e($p['property_description']))?></p>
<h6>Features</h6><div class="d-flex flex-wrap gap-2"><?php foreach($features as $f):?><span class="badge text-bg-light border"><?=e($f)?></span><?php endforeach;?><?php if(!$features):?><span class="text-muted">No features assigned.</span><?php endif;?></div>
</div></div></div>
<?php require '../includes/footer.php'; ?>
