# ESTATEPRO — REAL ESTATE MANAGEMENT SYSTEM
## College Project Report / Documentation

### 1. Abstract
EstatePro is a PHP and MySQL based Real Estate Management System designed to manage clients, agents, owners, properties, visits, rentals, sales, agreements, features and transaction documents. The system converts the supplied ER diagram into a practical web application with a responsive administrative dashboard, property search, photo management, analytics and printable reports.

### 2. Problem Statement
Manual property records can be difficult to search, update and report. The proposed system centralizes real-estate information and provides role-based administration, transaction tracking and document generation.

### 3. Objectives
- Store real-estate information in a normalized relational database.
- Manage property owners, clients and agents.
- Manage property listings and features.
- Track visits, rentals and sales.
- Provide property image uploads.
- Provide fast property search and filtering.
- Generate management reports.
- Generate printable invoices and receipts.
- Provide administrator and staff accounts.

### 4. Technology Stack
| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, Bootstrap 5, Bootstrap Icons, JavaScript |
| Charts | Chart.js |
| Backend | PHP 8+ |
| Database | MySQL 8 / MariaDB |
| Architecture | Server-rendered modular PHP |
| Security | PDO prepared statements, password hashing, CSRF tokens |

### 5. Main Modules
1. Authentication
2. Dashboard
3. Property Management
4. Client Management
5. Agent Management
6. Owner Management
7. Address Management
8. Feature Management
9. Client Wishes
10. Property Visits
11. Rental Management
12. Sales Management
13. Rental Agreements
14. Property Photos
15. Reports and Analytics
16. Invoices / Receipts
17. User and Role Management

### 6. Database Design
The database follows the supplied ER design and adds practical supporting tables:
- `users`
- `documents`
- `property_images`

Core entities include clients, agents, owners, properties, addresses, features, visits, rents, sales and rental agreements.

### 7. Security
- Passwords are stored using `password_hash()`.
- Database operations use PDO prepared statements.
- Forms use CSRF tokens.
- Uploaded images are validated by MIME type and file size.
- Uploaded filenames are randomized.
- Administrator pages require the ADMIN role.
- HTML output is escaped to reduce XSS risk.

### 8. System Workflow
**Login → Dashboard → Manage People → Add Property → Add Features/Photos → Schedule Visit → Rent/Sale → Generate Document → Reports**

### 9. Testing Plan
| Test | Expected Result |
|---|---|
| Valid login | Dashboard opens |
| Invalid login | Access denied |
| Add property | Property appears in listing |
| Property search | Matching records shown |
| Status filter | Correct status records shown |
| Upload valid image | Image appears in gallery |
| Upload invalid file | Upload rejected |
| Create invoice | Document appears in list |
| Print document | Browser print dialog opens |
| Non-admin opens admin | Access denied |
| Delete property | Related dependent records handled by FK |

### 10. Future Enhancements
- Email notifications
- Online payment gateway
- Google Maps integration
- REST API/mobile application
- Advanced audit logs
- Cloud image storage
- Automated PDF generation using a dedicated PDF library

### 11. Conclusion
EstatePro provides an integrated solution for real-estate record management and demonstrates database design, server-side programming, authentication, CRUD operations, reporting, file handling and responsive web development in a single academic project.
