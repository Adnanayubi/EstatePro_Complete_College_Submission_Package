<?php
$title='Dashboard'; require_once __DIR__ . '/includes/header.php';
$pdo=db();
$counts=[];
foreach([
 'clients'=>'SELECT COUNT(*) c FROM clients',
 'agents'=>'SELECT COUNT(*) c FROM agents',
 'owners'=>'SELECT COUNT(*) c FROM owners',
 'properties'=>'SELECT COUNT(*) c FROM properties',
 'visits'=>'SELECT COUNT(*) c FROM visits',
 'rentals'=>'SELECT COUNT(*) c FROM rents',
 'sales'=>'SELECT COUNT(*) c FROM sales'
] as $key=>$sql){$counts[$key]=(int)$pdo->query($sql)->fetch()['c'];}
$statusRows=$pdo->query("SELECT status,COUNT(*) total FROM properties GROUP BY status")->fetchAll();
$monthly=$pdo->query("SELECT DATE_FORMAT(sale_date,'%Y-%m') ym, SUM(sale_price) total FROM sales GROUP BY ym ORDER BY ym DESC LIMIT 6")->fetchAll();
$recent=$pdo->query("SELECT p.property_id,p.property_address,p.listing_type,p.status,p.created_at FROM properties p ORDER BY p.property_id DESC LIMIT 6")->fetchAll();
?>
<div class="hero text-white p-4 p-lg-5 mb-4">
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
    <div><div class="text-white-50 mb-2">College Project • Real Estate ERP</div><h1 class="fw-bold mb-2">Good day, <?=e(current_user()['full_name']??'Administrator')?>!</h1><p class="mb-0">A modern overview of your property business.</p></div>
    <div class="d-flex gap-2 no-print"><a class="btn btn-light" href="property/form.php"><i class="bi bi-plus-lg"></i> Add Property</a><a class="btn btn-outline-light" href="reports/index.php"><i class="bi bi-file-earmark-bar-graph"></i> Reports</a><a class="btn btn-outline-light" href="demo_data.php">Demo Data</a></div>
  </div>
</div>
<div class="row g-4 mb-4">
<?php $cards=[['properties','Properties','bi-houses'],['clients','Clients','bi-people'],['agents','Agents','bi-person-badge'],['owners','Owners','bi-person-vcard'],['visits','Visits','bi-calendar-check'],['rentals','Rentals','bi-key'],['sales','Sales','bi-currency-rupee']]; foreach($cards as [$k,$label,$icon]):?>
<div class="col-6 col-md-4 col-xl"><div class="card stat-card p-4"><div class="d-flex justify-content-between"><span class="text-muted"><?=$label?></span><i class="bi <?=$icon?> stat-icon text-primary"></i></div><div class="stat-number mt-2"><?=$counts[$k]?></div><div class="small text-muted">Total records</div></div></div>
<?php endforeach;?>
</div>
<div class="row g-4">
<div class="col-xl-7"><div class="card p-4"><div class="d-flex justify-content-between mb-3"><h5 class="mb-0">Property Status</h5><a class="small" href="property/index.php">View properties</a></div><canvas id="statusChart" height="130"></canvas></div></div>
<div class="col-xl-5"><div class="card p-4"><h5>Sales Trend</h5><canvas id="salesChart" height="170"></canvas></div></div>
<div class="col-12"><div class="card table-card"><div class="p-4 pb-2 d-flex justify-content-between"><h5>Recently Added Properties</h5><a class="btn btn-sm btn-outline-primary" href="property/index.php">View all</a></div><table class="table mb-0"><thead><tr><th>ID</th><th>Property</th><th>Type</th><th>Status</th><th>Added</th></tr></thead><tbody><?php foreach($recent as $r):?><tr><td>#<?=$r['property_id']?></td><td><?=e($r['property_address'])?></td><td><?=e($r['listing_type'])?></td><td><span class="badge badge-soft"><?=e($r['status'])?></span></td><td><?=e($r['created_at'])?></td></tr><?php endforeach;?></tbody></table></div></div>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('statusChart'),{type:'doughnut',data:{labels:<?=json_encode(array_column($statusRows,'status'))?>,datasets:[{data:<?=json_encode(array_map('intval',array_column($statusRows,'total')))?>}]},options:{responsive:true,plugins:{legend:{position:'bottom'}}}});
new Chart(document.getElementById('salesChart'),{type:'bar',data:{labels:<?=json_encode(array_reverse(array_column($monthly,'ym')))?>,datasets:[{label:'Sales value',data:<?=json_encode(array_map('floatval',array_reverse(array_column($monthly,'total'))))?>}]},options:{responsive:true,scales:{y:{beginAtZero:true}}}});
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
