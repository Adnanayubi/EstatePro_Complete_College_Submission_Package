<?php
declare(strict_types=1);

session_start();

define('APP_NAME', 'Real Estate Management System');
define('BASE_URL', '/real_estate');

define('DB_HOST', 'localhost');
define('DB_NAME', 'real_estate');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

date_default_timezone_set('Asia/Kolkata');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';


function is_admin(): bool {
    return (current_user()['role'] ?? '') === 'ADMIN';
}
function require_admin(): void {
    require_login();
    if (!is_admin()) {
        http_response_code(403);
        exit('Access denied. Administrator privileges are required.');
    }
}
function money(float|int|null $value): string {
    return number_format((float)$value, 2);
}
