<?php
require_once '../config/config.php';
$pdo=db();
$hash=password_hash('admin123',PASSWORD_DEFAULT);
$st=$pdo->prepare("INSERT INTO users(username,full_name,email,password_hash,role) VALUES('admin','Administrator','admin@example.com',?,'ADMIN') ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash),role='ADMIN',is_active=1");
$st->execute([$hash]);
echo 'Admin account ready. Username: admin | Password: admin123';
