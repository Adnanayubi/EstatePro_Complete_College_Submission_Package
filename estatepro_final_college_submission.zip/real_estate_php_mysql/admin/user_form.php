<?php
require_once '../config/config.php'; require_admin(); $pdo=db(); $id=query_int('id'); $editing=!!$id; $u=['username'=>'','full_name'=>'','email'=>'','role'=>'STAFF','is_active'=>1];
if($editing){$st=$pdo->prepare("SELECT * FROM users WHERE user_id=?");$st->execute([$id]);$u=$st->fetch();if(!$u)redirect('index.php');}
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$username=trim($_POST['username']);$full=trim($_POST['full_name']);$email=trim($_POST['email']);$role=$_POST['role'];$pass=$_POST['password']??'';
 try{
  if(!in_array($role,['ADMIN','AGENT','STAFF'],true))throw new Exception('Invalid role.');
  if($editing){
   if($pass!=='')$st=$pdo->prepare("UPDATE users SET username=?,full_name=?,email=?,role=?,password_hash=? WHERE user_id=?");else $st=$pdo->prepare("UPDATE users SET username=?,full_name=?,email=?,role=? WHERE user_id=?");
   if($pass!=='')$st->execute([$username,$full,$email,$role,password_hash($pass,PASSWORD_DEFAULT),$id]);else $st->execute([$username,$full,$email,$role,$id]);
  }else{$st=$pdo->prepare("INSERT INTO users(username,full_name,email,password_hash,role) VALUES(?,?,?,?,?)");$st->execute([$username,$full,$email,password_hash($pass?:'admin123',PASSWORD_DEFAULT),$role]);}
  flash('success',$editing?'User updated.':'User created.');redirect('admin/index.php');
 }catch(Throwable $e){$error=$e->getCode()===23000?'Username already exists.':$e->getMessage();}
}
$title=$editing?'Edit User':'Add User';require '../includes/header.php';?>
<div class="card p-4" style="max-width:800px"><h2><?=$title?></h2><?php if(isset($error)):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?><form method="post"><?=csrf_field()?><div class="row g-3"><div class="col-md-6"><label class="form-label">Full name</label><input required class="form-control" name="full_name" value="<?=e($u['full_name'])?>"></div><div class="col-md-6"><label class="form-label">Username</label><input required class="form-control" name="username" value="<?=e($u['username'])?>"></div><div class="col-md-6"><label class="form-label">Email</label><input type="email" class="form-control" name="email" value="<?=e($u['email'])?>"></div><div class="col-md-6"><label class="form-label">Role</label><select class="form-select" name="role"><?php foreach(['ADMIN','AGENT','STAFF'] as $r):?><option <?=$u['role']===$r?'selected':''?>><?=$r?></option><?php endforeach;?></select></div><div class="col-md-6"><label class="form-label">Password <?=$editing?'(leave blank to keep current)':''?></label><input <?=$editing?'':'required'?> type="password" class="form-control" name="password" minlength="6"></div></div><div class="mt-4"><button class="btn btn-primary">Save User</button> <a class="btn btn-outline-secondary" href="index.php">Cancel</a></div></form></div>
<?php require '../includes/footer.php'; ?>
