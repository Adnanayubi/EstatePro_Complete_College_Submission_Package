<?php
require_once '../config/config.php'; require_admin(); $pdo=db();
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf(); $action=$_POST['action']??'';
 if($action==='toggle'){ $id=(int)$_POST['user_id']; if($id!==(int)current_user()['user_id']){$pdo->prepare("UPDATE users SET is_active=1-is_active WHERE user_id=?")->execute([$id]);flash('success','User status updated.');} redirect('admin/index.php');}
}
$users=$pdo->query("SELECT user_id,username,full_name,email,role,is_active,created_at FROM users ORDER BY user_id DESC")->fetchAll();
$title='User Management';require '../includes/header.php';?>
<div class="d-flex justify-content-between align-items-center mb-4"><div><h2>User Management</h2><p class="text-muted mb-0">Create and control application accounts.</p></div><a class="btn btn-primary" href="user_form.php">Add User</a></div>
<div class="card table-card"><table class="table table-hover mb-0"><thead><tr><th>User</th><th>Email</th><th>Role</th><th>Status</th><th>Created</th><th></th></tr></thead><tbody>
<?php foreach($users as $u):?><tr><td><strong><?=e($u['full_name'])?></strong><br><small class="text-muted">@<?=e($u['username'])?></small></td><td><?=e($u['email'])?></td><td><span class="badge badge-soft"><?=e($u['role'])?></span></td><td><?= $u['is_active'] ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-secondary">Disabled</span>' ?></td><td><?=e($u['created_at'])?></td><td><a class="btn btn-sm btn-outline-primary" href="user_form.php?id=<?=$u['user_id']?>">Edit</a><?php if($u['user_id']!=(int)current_user()['user_id']):?><form class="d-inline" method="post"><?=csrf_field()?><input type="hidden" name="action" value="toggle"><input type="hidden" name="user_id" value="<?=$u['user_id']?>"><button class="btn btn-sm btn-outline-secondary"><?= $u['is_active']?'Disable':'Enable' ?></button></form><?php endif;?></td></tr><?php endforeach;?>
</tbody></table></div><?php require '../includes/footer.php'; ?>
