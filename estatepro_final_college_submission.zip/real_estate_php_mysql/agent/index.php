<?php $title='Agents'; require '../includes/header.php'; $rows=db()->query("SELECT * FROM agents ORDER BY agent_id DESC")->fetchAll(); ?>
<div class="d-flex justify-content-between mb-3"><h2>Agents</h2><a class="btn btn-primary" href="form.php">Add Agent</a></div>
<div class="card table-card"><table class="table table-hover mb-0"><thead><tr><th>ID</th><th>Name</th><th>Office</th><th>Phone</th><th>Actions</th></tr></thead><tbody>
<?php foreach($rows as $r):?><tr><td><?=$r['agent_id']?></td><td><?=e($r['agent_name'])?></td><td><?=e($r['office'])?></td><td><?=e($r['phone_num'])?></td><td><a class="btn btn-sm btn-outline-primary" href="form.php?id=<?=$r['agent_id']?>">Edit</a> <a data-confirm="Delete this agent?" class="btn btn-sm btn-outline-danger" href="delete.php?id=<?=$r['agent_id']?>">Delete</a></td></tr><?php endforeach;?>
</tbody></table></div><?php require '../includes/footer.php'; ?>
