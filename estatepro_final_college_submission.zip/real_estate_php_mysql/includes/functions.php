<?php
declare(strict_types=1);

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): never {
    header('Location: ' . BASE_URL . '/' . ltrim($path, '/'));
    exit;
}

function flash(string $key, ?string $message = null): ?string {
    if ($message !== null) {
        $_SESSION['_flash'][$key] = $message;
        return null;
    }
    $value = $_SESSION['_flash'][$key] ?? null;
    unset($_SESSION['_flash'][$key]);
    return $value;
}

function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['_csrf'] ?? '';
        if (!$token || !hash_equals($_SESSION['_csrf'] ?? '', $token)) {
            http_response_code(419);
            exit('Invalid CSRF token.');
        }
    }
}

function old(string $key, string $default = ''): string {
    return e($_POST[$key] ?? $default);
}

function post_int(string $key): ?int {
    $v = filter_input(INPUT_POST, $key, FILTER_VALIDATE_INT);
    return $v === false ? null : $v;
}

function post_decimal(string $key): ?float {
    $v = filter_input(INPUT_POST, $key, FILTER_VALIDATE_FLOAT);
    return $v === false ? null : $v;
}

function query_int(string $key): ?int {
    $v = filter_input(INPUT_GET, $key, FILTER_VALIDATE_INT);
    return $v === false ? null : $v;
}

function format_money($amount): string {
    return $amount === null || $amount === '' ? '-' : number_format((float)$amount, 2);
}
