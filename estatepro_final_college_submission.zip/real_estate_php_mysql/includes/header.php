<?php
require_once __DIR__ . '/../config/config.php';
require_login();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="<?= BASE_URL ?>/assets/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-xl navbar-dark shadow-sm no-print">
  <div class="container-fluid px-3 px-lg-4">
    <a class="navbar-brand fw-bold" href="<?= BASE_URL ?>/dashboard.php"><i class="bi bi-buildings"></i> EstatePro</a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/property/index.php"><i class="bi bi-house"></i> Properties</a></li>
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">People</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/client/index.php">Clients</a></li>
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/agent/index.php">Agents</a></li>
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/owner/index.php">Owners</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Transactions</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/visit/index.php">Visits</a></li>
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/rent/index.php">Rentals</a></li>
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/sale/index.php">Sales</a></li>
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/agreement/index.php">Rental Agreements</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Setup</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/address/index.php">Addresses</a></li>
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/feature/index.php">Features</a></li>
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/wish/index.php">Client Wishes</a></li>
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/property/features.php">Property Features</a></li>
          </ul>
        </li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/documents/index.php"><i class="bi bi-receipt"></i> Documents</a></li><li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/reports/index.php"><i class="bi bi-bar-chart"></i> Reports</a></li><?php if (is_admin()): ?><li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/admin/index.php"><i class="bi bi-shield-lock"></i> Admin</a></li><?php endif; ?>
      </ul>
      <span class="text-white-50 me-3 d-none d-lg-inline"><i class="bi bi-person-circle"></i> <?= e(current_user()['full_name'] ?? 'User') ?></span>
      <a class="btn btn-light btn-sm" href="<?= BASE_URL ?>/logout.php">Logout</a>
    </div>
  </div>
</nav>
<main class="container-fluid px-3 px-lg-4 py-4">
<?php if ($msg = flash('success')): ?><div class="alert alert-success no-print"><i class="bi bi-check-circle"></i> <?= e($msg) ?></div><?php endif; ?>
<?php if ($msg = flash('error')): ?><div class="alert alert-danger no-print"><i class="bi bi-exclamation-triangle"></i> <?= e($msg) ?></div><?php endif; ?>
