<?php
require_once '../config/config.php';
require_login(); verify_csrf();
$id=query_int('id'); $pdo=db();
$row=null;
if($id){$st=$pdo->prepare("SELECT * FROM clients WHERE client_id=?");$st->execute([$id]);$row=$st->fetch(); if(!$row) redirect('client/index.php');}
if($_SERVER['REQUEST_METHOD']==='POST'){
  $id=post_int('client_id'); $name=trim($_POST['client_name']??'');
  if($id){$st=$pdo->prepare("UPDATE clients SET client_name=?,client_address=?,phone_num=?,email=?,gender=?,username=? WHERE client_id=?");$st->execute([$name,$_POST['client_address']??'',$_POST['phone_num']??'',$_POST['email']??'',$_POST['gender']??'',$_POST['username']??'',$id]);}
  else {$st=$pdo->prepare("INSERT INTO clients(client_name,client_address,phone_num,email,gender,username) VALUES(?,?,?,?,?,?)");$st->execute([$name,$_POST['client_address']??'',$_POST['phone_num']??'',$_POST['email']??'',$_POST['gender']??'',$_POST['username']??'']);}
  flash('success','Client saved.'); redirect('client/index.php');
}
$title=$id?'Edit Client':'Add Client'; require '../includes/header.php';
?>
<h2><?=e($title)?></h2><div class="card p-4"><form method="post"><?=csrf_field()?><input type="hidden" name="client_id" value="<?=e((string)$id)?>">
<div class="row g-3">
<div class="col-md-6"><label class="form-label">Name</label><input required class="form-control" name="client_name" value="<?=e($row['client_name']??'')?>"></div>
<div class="col-md-6"><label class="form-label">Phone</label><input class="form-control" name="phone_num" value="<?=e($row['phone_num']??'')?>"></div>
<div class="col-md-6"><label class="form-label">Email</label><input type="email" class="form-control" name="email" value="<?=e($row['email']??'')?>"></div>
<div class="col-md-6"><label class="form-label">Gender</label><select class="form-select" name="gender"><option value="">Select</option><?php foreach(['Male','Female','Other'] as $g):?><option <?=$g===($row['gender']??'')?'selected':''?>><?=$g?></option><?php endforeach;?></select></div>
<div class="col-md-6"><label class="form-label">Address</label><input class="form-control" name="client_address" value="<?=e($row['client_address']??'')?>"></div>
<div class="col-md-6"><label class="form-label">Username</label><input class="form-control" name="username" value="<?=e($row['username']??'')?>"></div>
</div><button class="btn btn-primary mt-4">Save</button> <a class="btn btn-secondary mt-4" href="index.php">Cancel</a></form></div>
<?php require '../includes/footer.php'; ?>
