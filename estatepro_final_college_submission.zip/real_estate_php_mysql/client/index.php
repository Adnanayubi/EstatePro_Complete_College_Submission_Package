<?php
$title='Clients'; require_once '../includes/header.php';
$search=trim($_GET['search']??'');
$sql="SELECT * FROM clients WHERE client_name LIKE ? OR email LIKE ? ORDER BY client_id DESC";
$like="%$search%"; $st=db()->prepare($sql); $st->execute([$like,$like]); $rows=$st->fetchAll();
?>
<div class="d-flex justify-content-between align-items-center mb-3"><h2>Clients</h2><a class="btn btn-primary" href="form.php">Add Client</a></div>
<div class="card p-3 mb-3"><form class="row g-2"><div class="col-md-10"><input class="form-control" name="search" value="<?=e($search)?>" placeholder="Search name or email"></div><div class="col-md-2"><button class="btn btn-outline-primary w-100">Search</button></div></form></div>
<div class="card table-card"><table class="table table-hover mb-0"><thead><tr><th>ID</th><th>Name</th><th>Phone</th><th>Email</th><th>Gender</th><th>Actions</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?=$r['client_id']?></td><td><?=e($r['client_name'])?></td><td><?=e($r['phone_num'])?></td><td><?=e($r['email'])?></td><td><?=e($r['gender'])?></td><td><a class="btn btn-sm btn-outline-primary" href="form.php?id=<?=$r['client_id']?>">Edit</a> <a data-confirm="Delete this client?" class="btn btn-sm btn-outline-danger" href="delete.php?id=<?=$r['client_id']?>">Delete</a></td></tr><?php endforeach; ?>
</tbody></table></div>
<?php require '../includes/footer.php'; ?>
