<?php
require_once '../config/config.php'; require_login();
$id=query_int('id'); if($id){db()->prepare("DELETE FROM clients WHERE client_id=?")->execute([$id]); flash('success','Client deleted.');} redirect('client/index.php');
