# EstatePro — Real Estate Management System

A polished college-project edition of the PHP + MySQL application based on the supplied ER diagram.

## Highlights
- Modern responsive Bootstrap 5 admin dashboard
- Dashboard KPI cards and Chart.js analytics
- Property search and advanced filtering:
  - address/description
  - listing type
  - status
  - city
  - minimum rooms
  - maximum price
- Property photo upload/gallery
- Secure image validation and randomized filenames
- Printable property inventory reports
- Print / Save as PDF from browser
- Sales/rental summary reports
- Clients, agents, owners, addresses, features and client wishes
- Visits, rentals, rental agreements and sales
- PDO prepared statements
- CSRF protection
- Password hashing
- Responsive UI and print CSS

## Installation
1. Install XAMPP/WAMP/LAMP.
2. Extract this folder into `htdocs/real_estate`.
3. Start Apache and MySQL.
4. Create/import the `real_estate` database using `database/schema.sql`.
5. Visit `http://localhost/real_estate/setup.php`.
6. Login with `admin` / `admin123`.
7. Delete `setup.php` after setup.

## Upload permissions
PHP must be allowed to write to:
`uploads/properties/`

On Linux, make that directory writable by the web server user.

## PDF
The reports are intentionally print-friendly and use the browser's native Print dialog. Select **Save as PDF** to create a PDF without requiring an external PHP PDF package. This makes the college project easier to install on XAMPP.

## Suggested presentation/demo flow
Login → Dashboard → Add Owner/Client/Agent → Add Address → Add Property → Upload Property Photos → Add Features → Schedule Visit → Create Rental/Sale → Reports → Print/Save PDF.

## Final-submission additions
- Property detail/print page
- ADMIN/AGENT/STAFF user management
- Printable invoices, sale receipts and rent receipts
- College project report (`COLLEGE_PROJECT_REPORT.md`)
- Viva preparation sheet (`VIVA_QUESTIONS.md`)
- `admin/seed_admin.php` to initialize the administrator account after importing the schema
