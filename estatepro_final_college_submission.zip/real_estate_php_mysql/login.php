<?php
require_once __DIR__ . '/config/config.php';

if (is_logged_in()) redirect('dashboard.php');

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = db()->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        login_user($user);
        redirect('dashboard.php');
    }
    $error = 'Invalid username or password.';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= BASE_URL ?>/assets/style.css" rel="stylesheet">
</head>
<body>
<div class="login-wrap">
  <div class="card login-card p-4">
    <h2 class="fw-bold text-center mb-1">Real Estate</h2>
    <p class="text-center text-muted mb-4">Management System</p>
    <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
    <form method="post">
      <?= csrf_field() ?>
      <label class="form-label">Username</label>
      <input class="form-control mb-3" name="username" required autofocus>
      <label class="form-label">Password</label>
      <input class="form-control mb-4" type="password" name="password" required>
      <button class="btn btn-primary w-100">Login</button>
    </form>
    <div class="text-center mt-3 small text-muted">Default: admin / admin123</div>
  </div>
</div>
</body>
</html>
