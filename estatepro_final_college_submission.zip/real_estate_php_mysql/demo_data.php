<?php
require_once __DIR__ . '/config/config.php'; require_login(); verify_csrf();
$pdo=db();
if($_SERVER['REQUEST_METHOD']==='POST'){
  $pdo->beginTransaction();
  try{
    $pdo->exec("INSERT INTO owners(owner_name,phone_num) VALUES ('Rahul Sharma','9876543210'),('Priya Mehta','9123456780')");
    $pdo->exec("INSERT INTO agents(office,agent_name,phone_num) VALUES ('Central','Aman Verma','9000011111'),('North','Sara Khan','9000022222')");
    $pdo->exec("INSERT INTO clients(client_name,phone_num,email,gender) VALUES ('Rohan Singh','9888811111','rohan@example.com','Male'),('Ananya Rao','9777722222','ananya@example.com','Female')");
    $pdo->exec("INSERT INTO addresses(address_street,zip_code,country_name,city_name) VALUES ('12 MG Road','560001','India','Bengaluru'),('44 Park Street','700016','India','Kolkata'),('18 FC Road','411004','India','Pune')");
    $pdo->exec("INSERT INTO features(feature_description) VALUES ('Parking'),('Balcony'),('Garden'),('Security'),('Swimming Pool')");
    $addresses=$pdo->query("SELECT address_id FROM addresses ORDER BY address_id DESC LIMIT 3")->fetchAll(PDO::FETCH_COLUMN);
    $owners=$pdo->query("SELECT owner_id FROM owners ORDER BY owner_id DESC LIMIT 2")->fetchAll(PDO::FETCH_COLUMN);
    $pdo->prepare("INSERT INTO properties(property_date_add,property_address,property_num_of_rooms,property_num_of_bedroom,property_num_of_bathroom,property_num_of_garage,property_description,address_id,owner_id,listing_type,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)")
      ->execute([date('Y-m-d'),'12 MG Road, Bengaluru',4,3,2,1,'Modern family apartment near the city centre.',$addresses[2]??null,$owners[1]??null,'SALE','AVAILABLE']);
    $p=(int)$pdo->lastInsertId();
    $pdo->prepare("INSERT INTO property_for_sale(property_id,used_price,available_date) VALUES(?,?,?)")->execute([$p,8500000,date('Y-m-d')]);
    $pdo->prepare("INSERT INTO properties(property_date_add,property_address,property_num_of_rooms,property_num_of_bedroom,property_num_of_bathroom,property_num_of_garage,property_description,address_id,owner_id,listing_type,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)")
      ->execute([date('Y-m-d'),'44 Park Street, Kolkata',3,2,2,1,'Bright apartment with balcony and excellent transport links.',$addresses[1]??null,$owners[0]??null,'RENT','AVAILABLE']);
    $p=(int)$pdo->lastInsertId();
    $pdo->prepare("INSERT INTO property_for_rent(property_id,rent_price,available_date) VALUES(?,?,?)")->execute([$p,35000,date('Y-m-d')]);
    $pdo->commit(); flash('success','Demo data inserted.'); redirect('dashboard.php');
  }catch(Throwable $e){$pdo->rollBack();flash('error',$e->getMessage());}
}
$title='Demo Data';require __DIR__.'/includes/header.php';?>
<div class="card p-5"><h2>Insert Demo Data</h2><p>This creates sample clients, agents, owners, addresses, features and properties for a college presentation.</p><form method="post"><?=csrf_field()?><button class="btn btn-primary" data-confirm="Insert sample records?">Insert Demo Data</button></form></div><?php require __DIR__.'/includes/footer.php'; ?>
