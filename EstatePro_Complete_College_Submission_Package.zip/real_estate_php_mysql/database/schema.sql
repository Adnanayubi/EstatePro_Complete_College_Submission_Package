CREATE TABLE IF NOT EXISTS users (
    user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(120),
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('ADMIN','AGENT','STAFF') NOT NULL DEFAULT 'STAFF',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS addresses (
    address_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    address_street VARCHAR(255),
    zip_code VARCHAR(20),
    country_name VARCHAR(100),
    city_name VARCHAR(100),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS clients (
    client_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    client_name VARCHAR(100) NOT NULL,
    client_address VARCHAR(255),
    phone_num VARCHAR(30),
    email VARCHAR(150),
    gender VARCHAR(20),
    username VARCHAR(45) UNIQUE,
    password_hash VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS agents (
    agent_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    office VARCHAR(100),
    agent_name VARCHAR(100) NOT NULL,
    phone_num VARCHAR(30),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS owners (
    owner_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    owner_name VARCHAR(100) NOT NULL,
    phone_num VARCHAR(30),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS features (
    feature_code INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    feature_description VARCHAR(255) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS properties (
    property_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    property_date_add DATE,
    property_address VARCHAR(255),
    client_id INT UNSIGNED NULL,
    property_num_of_rooms INT,
    property_num_of_bedroom INT,
    property_num_of_bathroom INT,
    property_num_of_garage INT,
    property_description TEXT,
    address_id INT UNSIGNED NULL,
    owner_id INT UNSIGNED NULL,
    listing_type ENUM('RENT','SALE','BOTH') NOT NULL DEFAULT 'RENT',
    status ENUM('AVAILABLE','RENTED','SOLD','INACTIVE') NOT NULL DEFAULT 'AVAILABLE',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_property_client FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_property_address FOREIGN KEY (address_id) REFERENCES addresses(address_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_property_owner FOREIGN KEY (owner_id) REFERENCES owners(owner_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS property_for_rent (
    property_id INT UNSIGNED PRIMARY KEY,
    rent_price DECIMAL(12,2) NOT NULL DEFAULT 0,
    available_date DATE NULL,
    CONSTRAINT fk_rent_property FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS property_for_sale (
    property_id INT UNSIGNED PRIMARY KEY,
    used_price DECIMAL(14,2) NOT NULL DEFAULT 0,
    available_date DATE NULL,
    CONSTRAINT fk_sale_property FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS property_features (
    property_id INT UNSIGNED NOT NULL,
    feature_code INT UNSIGNED NOT NULL,
    PRIMARY KEY (property_id, feature_code),
    CONSTRAINT fk_pf_property FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_pf_feature FOREIGN KEY (feature_code) REFERENCES features(feature_code) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS client_wishes (
    client_id INT UNSIGNED NOT NULL,
    feature_code INT UNSIGNED NOT NULL,
    PRIMARY KEY (client_id, feature_code),
    CONSTRAINT fk_cw_client FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_cw_feature FOREIGN KEY (feature_code) REFERENCES features(feature_code) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS visits (
    visit_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    client_id INT UNSIGNED NOT NULL,
    agent_id INT UNSIGNED NOT NULL,
    property_id INT UNSIGNED NOT NULL,
    visit_date DATETIME NOT NULL,
    notes VARCHAR(500),
    CONSTRAINT fk_visit_client FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_visit_agent FOREIGN KEY (agent_id) REFERENCES agents(agent_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_visit_property FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS rental_agreements (
    rental_agreement_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    rental_agreement_content TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS rents (
    rent_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    client_id INT UNSIGNED NOT NULL,
    agent_id INT UNSIGNED NOT NULL,
    property_id INT UNSIGNED NOT NULL,
    rental_date DATE NOT NULL,
    rent_end_date DATE NULL,
    rent_price DECIMAL(12,2) NOT NULL DEFAULT 0,
    rental_agreement_id INT UNSIGNED NULL,
    CONSTRAINT fk_rent_client FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_rent_agent FOREIGN KEY (agent_id) REFERENCES agents(agent_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_rent_property_tx FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_rent_agreement FOREIGN KEY (rental_agreement_id) REFERENCES rental_agreements(rental_agreement_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sales (
    sale_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    client_id INT UNSIGNED NOT NULL,
    agent_id INT UNSIGNED NOT NULL,
    property_id INT UNSIGNED NOT NULL,
    sale_date DATE NOT NULL,
    sale_price DECIMAL(14,2) NOT NULL DEFAULT 0,
    CONSTRAINT fk_sale_client FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_sale_agent FOREIGN KEY (agent_id) REFERENCES agents(agent_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_sale_property_tx FOREIGN KEY (property_id) REFERENCES properties(property_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS property_images (
    image_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    property_id INT UNSIGNED NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    original_name VARCHAR(255),
    uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_property_image_property
        FOREIGN KEY (property_id) REFERENCES properties(property_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_property_status ON properties(status);
CREATE INDEX idx_property_listing_type ON properties(listing_type);
CREATE INDEX idx_property_rooms ON properties(property_num_of_rooms);
CREATE INDEX idx_property_owner ON properties(owner_id);
CREATE INDEX idx_property_city ON addresses(city_name);
CREATE INDEX idx_visits_date ON visits(visit_date);
CREATE INDEX idx_sales_date ON sales(sale_date);
CREATE INDEX idx_rents_date ON rents(rental_date);

CREATE TABLE IF NOT EXISTS documents (
    document_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    document_no VARCHAR(40) NOT NULL UNIQUE,
    document_type ENUM('SALE_RECEIPT','RENT_RECEIPT','INVOICE') NOT NULL,
    property_id INT UNSIGNED NULL,
    client_id INT UNSIGNED NULL,
    agent_id INT UNSIGNED NULL,
    amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    description VARCHAR(255),
    issue_date DATE NOT NULL,
    created_by INT UNSIGNED NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_doc_property FOREIGN KEY(property_id) REFERENCES properties(property_id) ON DELETE SET NULL,
    CONSTRAINT fk_doc_client FOREIGN KEY(client_id) REFERENCES clients(client_id) ON DELETE SET NULL,
    CONSTRAINT fk_doc_agent FOREIGN KEY(agent_id) REFERENCES agents(agent_id) ON DELETE SET NULL,
    CONSTRAINT fk_doc_user FOREIGN KEY(created_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE INDEX idx_documents_date ON documents(issue_date);
CREATE INDEX idx_documents_type ON documents(document_type);
