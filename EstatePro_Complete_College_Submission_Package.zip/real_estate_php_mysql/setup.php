<?php
require_once __DIR__ . '/config/config.php';

$messages = [];
$error = null;

try {
    $pdo = db();

    $schema = file_get_contents(__DIR__ . '/database/schema.sql');
    $statements = preg_split('/;\s*(?:\r?\n|$)/', $schema);
    foreach ($statements as $statement) {
        $statement = trim($statement);
        if ($statement !== '' && !str_starts_with($statement, '--')) {
            $pdo->exec($statement);
        }
    }

    $check = $pdo->prepare("SELECT user_id FROM users WHERE username = ?");
    $check->execute(['admin']);
    if (!$check->fetch()) {
        $hash = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, full_name, email, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['admin', $hash, 'System Administrator', 'admin@example.com', 'ADMIN']);
        $messages[] = 'Database installed and admin account created.';
    } else {
        $messages[] = 'Database already exists. Admin account was not duplicated.';
    }
} catch (Throwable $e) {
    $error = $e->getMessage();
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Setup</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light">
<div class="container py-5">
<div class="card p-4 mx-auto" style="max-width:760px">
<h2>Real Estate System Setup</h2>
<?php if ($error): ?><div class="alert alert-danger"><strong>Setup failed:</strong><br><?= e($error) ?></div><?php else: ?>
<div class="alert alert-success"><?= e(implode(' ', $messages)) ?></div>
<p>Login with <strong>admin</strong> / <strong>admin123</strong>.</p>
<a class="btn btn-primary" href="<?= BASE_URL ?>/login.php">Go to Login</a>
<?php endif; ?>
<p class="mt-4 mb-0 text-danger small">Delete setup.php after installation.</p>
</div></div>
</body></html>
