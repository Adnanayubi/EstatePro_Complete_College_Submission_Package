# EstatePro College Submission Package

## Included
- `EstatePro_College_Project_Presentation.pptx` — viva/presentation slides
- `EstatePro_College_Project_Report.docx` — editable formatted report
- `EstatePro_College_Project_Report.pdf` — print-ready report
- `diagrams/ER_Diagram_Conceptual.png` — ER diagram
- `diagrams/DFD_Level_0_Context.png` — DFD Level 0
- `diagrams/DFD_Level_1.png` — DFD Level 1
- `diagrams/DFD_Level_2.png` — DFD Level 2
- `diagrams/Use_Case_Diagram.png` — use-case diagram
- `diagrams/Database_Schema_Physical.png` — physical database schema
- `diagram_sources/*.dot` — editable Graphviz sources
- `../real_estate_php_mysql/` — complete PHP + MySQL application

## Recommended submission order
1. Project report PDF
2. Project report DOCX
3. PPT presentation
4. Diagrams
5. Source code
6. Database schema

## Setup
1. Copy `real_estate_php_mysql` to the XAMPP `htdocs` directory.
2. Create/configure the MySQL database settings in `config/config.php`.
3. Open `setup.php` once in the browser.
4. Login with `admin / admin123`.
5. Delete or protect `setup.php` after installation.
6. Use `demo_data.php` for sample presentation data if required.

## Note
The database schema was normalized for the enhanced project and the `users` table is role-aware (`ADMIN`, `AGENT`, `STAFF`) so the admin module works correctly.
